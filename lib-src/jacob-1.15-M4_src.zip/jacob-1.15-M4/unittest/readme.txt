This directory contains junit tests and other/older tests for
specific functions.  Sometimes tests in this directory migrate
to the samples directory as they are updated to show more functionality.