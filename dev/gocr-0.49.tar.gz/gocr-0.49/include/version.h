#define version_string "0.49"
#define release_string "20100924"
