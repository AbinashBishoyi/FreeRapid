/* include/config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define to empty if the keyword does not work.  */
#undef const

/* Define if the setvbuf function takes the buffering type as its second
   argument and the buffer pointer as the third, as on System V
   before release 3.  */
#undef SETVBUF_REVERSED

/* Define if you have the ANSI C header files.  */
#undef STDC_HEADERS

/* Define if you have the gettimeofday function.  */
#undef HAVE_GETTIMEOFDAY

/* Define if you have the popen function.  */
#undef HAVE_POPEN

/* Define if you have the wcschr function.  */
#undef HAVE_WCSCHR

/* Define if you have the wcsdup function.  */
#undef HAVE_WCSDUP

/* Define if you have the <pam.h> header file.  */
#undef HAVE_PAM_H

/* Define if you have the <pnm.h> header file.  */
#undef HAVE_PNM_H

/* Define if you have the <unistd.h> header file.  */
#undef HAVE_UNISTD_H

/* Define if you have the <wchar.h> header file.  */
#undef HAVE_WCHAR_H
